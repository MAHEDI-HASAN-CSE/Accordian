import { useState} from "react";
import "./App.css";
import { IoIosArrowDown } from "react-icons/io";
import { IoIosArrowUp } from "react-icons/io";

const App = () => {
  const [track, settrack] = useState([]);
  const [val, setval] = useState("");
  const [cat, setcat] = useState("All");
  const [favoriate, setfavoriate] = useState([]);

  const questions = [
    {
      id: 1,
      question: "What is React?",
      answer:
        "React is a JavaScript library for building user interfaces, especially single-page applications.",
      category: "React",
      flp: false,
    },
    {
      id: 2,
      question: "What is JSX?",
      answer:
        "JSX is a syntax extension for JavaScript that allows us to write HTML-like code inside JavaScript.",
      category: "React",
      flp: false,
    },
    {
      id: 3,
      question: "What is useState?",
      answer:
        "useState is a React Hook that allows a component to store and update state.",
      category: "React",
      flp: false,
    },
    {
      id: 4,
      question: "What is useEffect?",
      answer:
        "useEffect is a React Hook used for performing side effects such as API calls, timers, and event listeners.",
      category: "React",
      flp: false,
    },
    {
      id: 5,
      question: "What are props?",
      answer:
        "Props are data passed from a parent component to a child component.",
      category: "React",
      flp: false,
    },

    {
      id: 6,
      question: "What is JavaScript?",
      answer:
        "JavaScript is a programming language used to make web pages interactive.",
      category: "JavaScript",
      flp: false,
    },
    {
      id: 7,
      question: "What is an array?",
      answer: "An array is a data structure used to store multiple values.",
      category: "JavaScript",
      flp: false,
    },

    {
      id: 8,
      question: "What is CSS?",
      answer: "CSS is used to style and design HTML elements.",
      category: "CSS",
      flp: false,
    },

    {
      id: 9,
      question: "What is Django?",
      answer:
        "Django is a Python web framework used to build web applications.",
      category: "Django",
      flp: false,
    },
  ];

  const Toggle = (index) => {
    if (track.includes(index)) {
      const newar = track.filter((val) => val != index);
      settrack(newar);
    } else {
      settrack([...track, index]);
    }
  };

  let tempquestions = [...questions];

  const alt = (str) => {
    setcat(str);
  };

  if (cat === "Favorite") {
    tempquestions = questions.filter((itm) => {
      return favoriate.includes(itm.id);
    });
  } else if (cat !== "All") {
    tempquestions = questions.filter((itm) => {
      return itm.category.toLowerCase() === cat.toLowerCase();
    });
  } else {
    tempquestions = [...questions];
  }

  const fav = (id) => {
    if (favoriate.includes(id)) {
      setfavoriate(favoriate.filter((val) => val != id));
    } else {
      setfavoriate([...favoriate, id]);
    }
  };

  if (val !== "") {
    tempquestions = tempquestions.filter((itm) => {
      return itm.question.toLowerCase().includes(val.toLowerCase());
    });
  }

  return (
    <div>
      <h1>Accordian project..</h1>
      <input
        type="text"
        placeholder="search"
        value={val}
        onChange={(e) => setval(e.target.value)}
      />
      <br />
      <br />
      <div className="btn">
        <button onClick={() => alt("All")}>All</button>
        <button onClick={() => alt("React")}>React</button>
        <button onClick={() => alt("JavaScript")}>JavaScript</button>
        <button onClick={() => alt("Favorite")}>Favoriate {favoriate.length}❤️</button>
        <button onClick={() => alt("CSS")}>CSS</button>
        <button onClick={() => alt("Django")}>Django</button>
      </div>
      <br />
      {tempquestions.length > 0 ? (
        tempquestions.map((items, index) => {
          return (
            <div key={index}>
              <div className={track.includes(index) ? "inn" : ""}>
                <button className="btnsty" onClick={() => Toggle(index)}>
                  {items.question}{" "}
                  {track.includes(index) ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </button>
                <button onClick={() => fav(items.id)}>
                  {favoriate.includes(items.id) ? "❤️" : "🤍"}
                </button>

                {track.includes(index) && <h4>{items.answer}</h4>}
              </div>
              <br />
            </div>
          );
        })
      ) : (
        <h4>now found</h4>
      )}
    </div>
  );
};

export default App;
